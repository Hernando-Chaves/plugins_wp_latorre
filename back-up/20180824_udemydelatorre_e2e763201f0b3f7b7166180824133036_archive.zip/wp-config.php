<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'udemy_delatorre');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Ub*7@GqVY;Q2N/EoW}A9dvJ4M@NK1RkNuV&I/]}q$E!aU:3jkKZCHs PSJEuefA?');
define('SECURE_AUTH_KEY',  '`yw^2X<;eDg?o({6Ll_*A3neO2Y^<VKpLk./8*C:N5~{z6qz$>jF0z$e|Al>T- a');
define('LOGGED_IN_KEY',    'qlCM=0+zP2b$_#kX[&qaTS-Sj<de_U*-]?P(Qj_%GGJPVWJ?3AF0{t;oZFFiy9b+');
define('NONCE_KEY',        'S;x?gMg]6l)N{$V(SJ={):>F,o$_:[p*^MV<9yZJl%=%e8{[<X*DK0l-7.z&Z}DW');
define('AUTH_SALT',        'ahX:}|8wH:3+2-jy.*]heWFW =}x(]4pJm7EK)u$|;Y7C:=xB+CFP`wi3R,a@UQ@');
define('SECURE_AUTH_SALT', '9rWfg9^c6sM[ |n@dB{/Br@nlwv;qOh |.+h6&7*/`GY;c`vWQ}j)BY`dJ^0]Qa>');
define('LOGGED_IN_SALT',   ':}@FDOGEX%?YT5sai2]gT/Sn3f:JQ@J[KjKjT(1S?kS.!iRA{]Dvfehc85H*>QI-');
define('NONCE_SALT',       'I|6,CL@%$x)IbB6IRI[;IC|9NOR4nMc.n ]f^hMru^Iu9{h<dCJYn>.UN>3>zSOn');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'delatorre_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
